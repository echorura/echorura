module.exports=[96938,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_support_ticket_route_actions_0n~vq.t.js.map