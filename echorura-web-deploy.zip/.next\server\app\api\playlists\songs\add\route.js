var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/playlists/songs/add/route.js")
R.c("server/chunks/[root-of-the-server]__01we3nt._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_playlists_songs_add_route_actions_0u4.r-i.js")
R.m(2750)
module.exports=R.m(2750).exports
