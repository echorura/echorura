module.exports=[98270,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_songs_create_route_actions_0eznni6.js.map