1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/14w3fan_5dg.k.js","/_next/static/chunks/09ldg6y~4v~pv.js","/_next/static/chunks/106e28ra4mk1o.js","/_next/static/chunks/0awmnm.om5114.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/_next/static/chunks/14w3fan_5dg.k.js","/_next/static/chunks/09ldg6y~4v~pv.js","/_next/static/chunks/106e28ra4mk1o.js","/_next/static/chunks/0awmnm.om5114.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"iWb1YW3C6Fh_X2Q4pv5WM"}
