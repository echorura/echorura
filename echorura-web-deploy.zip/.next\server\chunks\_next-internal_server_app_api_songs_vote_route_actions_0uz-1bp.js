module.exports=[73819,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_songs_vote_route_actions_0uz-1bp.js.map