globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/iWb1YW3C6Fh_X2Q4pv5WM/_buildManifest.js",
    "static/iWb1YW3C6Fh_X2Q4pv5WM/_ssgManifest.js",
    "static/iWb1YW3C6Fh_X2Q4pv5WM/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15pjn.n4_q6le.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/146sdk_xsv59a.js",
    "static/chunks/turbopack-0aro_t_w~ysxk.js"
  ]
};
