var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/playlists/songs/remove/route.js")
R.c("server/chunks/[root-of-the-server]__0.sxmo5._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_playlists_songs_remove_route_actions_0-07qdp.js")
R.m(1317)
module.exports=R.m(1317).exports
