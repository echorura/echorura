var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rewards/play/route.js")
R.c("server/chunks/[root-of-the-server]__0~de.yl._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_rewards_play_route_actions_0_nh1t0.js")
R.m(48966)
module.exports=R.m(48966).exports
