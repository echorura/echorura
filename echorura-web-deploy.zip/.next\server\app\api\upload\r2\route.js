var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/r2/route.js")
R.c("server/chunks/[root-of-the-server]__0dr~e_e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_r2_route_actions_138wb0j.js")
R.m(36914)
module.exports=R.m(36914).exports
