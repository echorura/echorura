module.exports=[69971,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_cover_route_actions_0i9~l6n.js.map