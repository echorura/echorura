module.exports=[2638,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rewards_play_route_actions_0_nh1t0.js.map