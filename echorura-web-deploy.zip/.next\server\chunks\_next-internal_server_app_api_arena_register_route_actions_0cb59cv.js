module.exports=[27687,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_arena_register_route_actions_0cb59cv.js.map