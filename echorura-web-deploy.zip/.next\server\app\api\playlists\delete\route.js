var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/playlists/delete/route.js")
R.c("server/chunks/[root-of-the-server]__06xn5ry._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_playlists_delete_route_actions_12v.3ke.js")
R.m(87698)
module.exports=R.m(87698).exports
