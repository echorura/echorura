var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/songs/create/route.js")
R.c("server/chunks/[root-of-the-server]__02z-2wo._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_songs_create_route_actions_0eznni6.js")
R.m(13340)
module.exports=R.m(13340).exports
