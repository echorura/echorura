var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/songs/download/route.js")
R.c("server/chunks/[root-of-the-server]__0kugxlg._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_songs_download_route_actions_0s.1qbg.js")
R.m(13321)
module.exports=R.m(13321).exports
