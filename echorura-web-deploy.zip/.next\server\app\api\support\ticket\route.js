var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/support/ticket/route.js")
R.c("server/chunks/[externals]__0k-jkif._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__07ycmfi._.js")
R.c("server/chunks/_next-internal_server_app_api_support_ticket_route_actions_0n~vq.t.js")
R.m(4332)
module.exports=R.m(4332).exports
