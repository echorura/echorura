:HL["/_next/static/chunks/0qm8oixk2a-b5.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"market","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"iWb1YW3C6Fh_X2Q4pv5WM"}
