var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/cover/route.js")
R.c("server/chunks/[root-of-the-server]__09~65dy._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_cover_route_actions_0i9~l6n.js")
R.m(71812)
module.exports=R.m(71812).exports
