var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/songs/update/route.js")
R.c("server/chunks/[root-of-the-server]__02d8-.6._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_songs_update_route_actions_10wvrm3.js")
R.m(76699)
module.exports=R.m(76699).exports
