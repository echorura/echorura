var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/playlists/list/route.js")
R.c("server/chunks/[root-of-the-server]__0homus-._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_playlists_list_route_actions_0ln0l2n.js")
R.m(25803)
module.exports=R.m(25803).exports
