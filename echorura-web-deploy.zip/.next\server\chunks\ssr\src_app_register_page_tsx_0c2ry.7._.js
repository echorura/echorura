module.exports=[55606,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(11955);a.s(["default",0,function(){let a=(0,c.useRouter)();return(0,b.jsx)("div",{className:"fixed inset-0 z-50 bg-black/80 flex items-center justify-center",children:(0,b.jsx)(d.default,{isOpen:!0,onClose:()=>a.push("/"),initialIsLogin:!1})})}])}];

//# sourceMappingURL=src_app_register_page_tsx_0c2ry.7._.js.map