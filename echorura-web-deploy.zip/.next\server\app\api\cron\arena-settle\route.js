var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/arena-settle/route.js")
R.c("server/chunks/[root-of-the-server]__0260vtb._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_arena-settle_route_actions_0evj2.h.js")
R.m(48685)
module.exports=R.m(48685).exports
