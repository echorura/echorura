module.exports=[88660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_arena_vote_route_actions_0_dnybj.js.map