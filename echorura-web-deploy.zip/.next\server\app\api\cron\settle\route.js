var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/settle/route.js")
R.c("server/chunks/[root-of-the-server]__0q1bu_n._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_settle_route_actions_0i504kt.js")
R.m(50197)
module.exports=R.m(50197).exports
