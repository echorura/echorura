var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/arena/register/route.js")
R.c("server/chunks/[root-of-the-server]__12po3-i._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_arena_register_route_actions_0cb59cv.js")
R.m(33303)
module.exports=R.m(33303).exports
