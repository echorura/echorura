var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/songs/vote/route.js")
R.c("server/chunks/[root-of-the-server]__0fm8-fi._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_songs_vote_route_actions_0uz-1bp.js")
R.m(93220)
module.exports=R.m(93220).exports
