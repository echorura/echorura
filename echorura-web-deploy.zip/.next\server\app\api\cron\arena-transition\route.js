var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/arena-transition/route.js")
R.c("server/chunks/[root-of-the-server]__0et0q3j._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_arena-transition_route_actions_0tpw6yp.js")
R.m(24072)
module.exports=R.m(24072).exports
