'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/utils/supabase/client';
import { X, Mail, Lock, Loader2, Phone, KeyRound, UserPlus } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialIsLogin?: boolean;
}

const getFriendlyErrorMessage = (err: any, defaultMsg: string) => {
  if (!err) return defaultMsg;
  const message = err.message || '';
  if (message.includes('SignatureDoesNotMatch') || message.includes('sendPhoneConfirmation')) {
    return '短信发送失败：短信服务配置有误（签名或凭证不匹配），请联系系统管理员检查后台配置。';
  }
  if (message.includes('User already registered') || message.includes('already exists')) {
    return '该手机号已注册，请直接登录或使用找回密码功能。';
  }
  return message || defaultMsg;
};

export default function AuthModal({ isOpen, onClose, initialIsLogin = true }: AuthModalProps) {
  const [authMethod, setAuthMethod] = useState<'phone' | 'email'>('phone');
  const [isLogin, setIsLogin] = useState(initialIsLogin);
  const [referrerPhone, setReferrerPhone] = useState('');

  // Phone auth mode: login (登录) / register (注册) / forgot (忘记密码)
  const [phoneMode, setPhoneMode] = useState<'login' | 'register' | 'forgot'>(initialIsLogin ? 'login' : 'register');

  // Email states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Phone states
  const [phone, setPhone] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [countdown, setCountdown] = useState(0);
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [newPassword, setNewPassword] = useState(''); // for forgot password

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const supabase = createClient();

  const handleSuccessRedirect = () => {
    onClose();
    if (typeof window !== 'undefined') {
      if (window.location.pathname === '/register') {
        window.location.href = '/';
      } else {
        window.location.reload();
      }
    }
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [countdown]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get('ref');
      if (ref) {
        setReferrerPhone(ref);
        setPhoneMode('register');
        setIsLogin(false);
      }
    }
  }, []);

  if (!isOpen) return null;

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || 'https://www.echorura.com'}/`,
            data: {
              referrer_phone: referrerPhone
            }
          }
        });
        if (error) throw error;
        alert('注册成功！请查收邮件确认，或直接尝试登录。');
      }
      handleSuccessRedirect();
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err, '操作失败，请重试'));
    } finally {
      setLoading(false);
    }
  };

  // 1. 发送注册验证码 (调用 signUp 发送验证码)
  const handleSendRegisterOtp = async () => {
    if (!phone || !password) {
      setError('请输入手机号和自设密码');
      return;
    }
    if (password.length < 6) {
      setError('密码长度不能少于 6 位');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const formattedPhone = phone.startsWith('+') ? phone : `+86${phone}`;
      const { error } = await supabase.auth.signUp({
        phone: formattedPhone,
        password: password,
        options: {
          data: {
            referrer_phone: referrerPhone
          }
        }
      });
      if (error) throw error;

      setIsOtpSent(true);
      setCountdown(60);
      alert('注册验证码已发送，请查收短信。');
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err, '发送验证码失败，可能该手机号已注册'));
    } finally {
      setLoading(false);
    }
  };

  // 2. 发送忘记密码验证码 (调用 signInWithOtp 发送验证码)
  const handleSendForgotOtp = async () => {
    if (!phone) {
      setError('请输入手机号');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const formattedPhone = phone.startsWith('+') ? phone : `+86${phone}`;
      const { error } = await supabase.auth.signInWithOtp({ phone: formattedPhone });
      if (error) throw error;

      setIsOtpSent(true);
      setCountdown(60);
      alert('验证码已发送，请查收短信。');
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err, '发送验证码失败'));
    } finally {
      setLoading(false);
    }
  };

  // 3. 手机号 + 密码 登录
  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) {
      setError('请输入手机号和密码');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const formattedPhone = phone.startsWith('+') ? phone : `+86${phone}`;
      const { error } = await supabase.auth.signInWithPassword({
        phone: formattedPhone,
        password: password,
      });
      if (error) throw error;

      handleSuccessRedirect();
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err, '登录失败，请检查手机号和密码'));
    } finally {
      setLoading(false);
    }
  };

  // 4. 手机号注册 (提交验证码)
  const handlePhoneRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOtpSent) {
      return handleSendRegisterOtp();
    }
    if (!otpCode) {
      setError('请输入短信验证码');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const formattedPhone = phone.startsWith('+') ? phone : `+86${phone}`;
      const { error } = await supabase.auth.verifyOtp({
        phone: formattedPhone,
        token: otpCode,
        type: 'sms',
      });
      if (error) throw error;

      alert('注册成功！已为您自动登录。');
      handleSuccessRedirect();
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err, '验证码错误，请重试'));
    } finally {
      setLoading(false);
    }
  };

  // 5. 忘记密码重置 (提交验证码和新密码)
  const handlePhoneResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOtpSent) {
      return handleSendForgotOtp();
    }
    if (!otpCode || !newPassword) {
      setError('请输入验证码和新密码');
      return;
    }
    if (newPassword.length < 6) {
      setError('新密码长度不能少于 6 位');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const formattedPhone = phone.startsWith('+') ? phone : `+86${phone}`;
      // 验证 OTP 登录
      const { error: verifyError } = await supabase.auth.verifyOtp({
        phone: formattedPhone,
        token: otpCode,
        type: 'sms',
      });
      if (verifyError) throw verifyError;

      // 验证成功后用户已登录，直接修改密码
      const { error: updateError } = await supabase.auth.updateUser({
        password: newPassword,
      });
      if (updateError) throw updateError;

      alert('密码重置成功，已自动登录！');
      handleSuccessRedirect();
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err, '重置密码失败，请重试'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md glass-panel rounded-3xl p-8 border border-white/10 shadow-2xl">
        <button onClick={onClose} className="absolute top-6 right-6 text-gray-400 hover:text-white transition-colors">
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-black text-white mb-2 uppercase tracking-tighter">
            {authMethod === 'phone' ? (
              phoneMode === 'login' ? '手机号登录' :
                phoneMode === 'register' ? '手机号注册' :
                  '找回密码'
            ) : (
              isLogin ? '欢迎回来' : '开启 ECHORURA'
            )}
          </h2>
          <p className="text-gray-400 text-sm">
            {authMethod === 'phone' ? (
              phoneMode === 'login' ? '使用手机号与密码登录极声' :
                phoneMode === 'register' ? '填写手机号与密码，获取验证码激活' :
                  '填写手机号并验证以重置密码'
            ) : (
              '加入民主化音乐社区，共享创作收益'
            )}
          </p>
        </div>

        {/* Auth Method Tabs */}
        <div className="flex bg-white/5 rounded-2xl p-1 mb-6">
          <button
            onClick={() => { setAuthMethod('phone'); setError(null); }}
            className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all ${authMethod === 'phone' ? 'bg-echo-primary text-black shadow-lg' : 'text-gray-400 hover:text-white'
              }`}
          >
            手机号账号
          </button>
          <button
            onClick={() => { setAuthMethod('email'); setError(null); }}
            className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all ${authMethod === 'email' ? 'bg-white/10 text-white shadow-lg' : 'text-gray-400 hover:text-white'
              }`}
          >
            邮箱账号
          </button>
        </div>

        {authMethod === 'phone' ? (
          phoneMode === 'login' ? (
            /* 1. 手机号 + 密码 登录表单 */
            <form onSubmit={handlePhoneLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase ml-1">手机号码</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="13800138000"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                  <label className="text-xs font-bold text-gray-400 uppercase">登录密码</label>
                  <button
                    type="button"
                    onClick={() => { setPhoneMode('forgot'); setError(null); setIsOtpSent(false); }}
                    className="text-xs text-echo-primary hover:underline transition-all"
                  >
                    忘记密码？
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              {error && <div className="text-red-400 text-xs bg-red-400/10 p-3 rounded-xl border border-red-400/20">{error}</div>}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-echo-primary to-echo-secondary text-black font-black py-4 rounded-2xl shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '立即登录'}
              </button>

              <div className="mt-4 text-center">
                <button
                  type="button"
                  onClick={() => { setPhoneMode('register'); setError(null); setIsOtpSent(false); }}
                  className="text-sm text-gray-400 hover:text-echo-primary transition-colors"
                >
                  还没有账号？点击注册
                </button>
              </div>
            </form>
          ) : phoneMode === 'register' ? (
            /* 2. 手机号 + 密码 注册表单（带验证码） */
            <form onSubmit={handlePhoneRegisterSubmit} className="space-y-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">手机号码</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-12 pr-4 text-xs text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="13800138000"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">自设密码 (不低于6位)</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-12 pr-4 text-xs text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1 flex items-center justify-between">
                  <span>邀请码 (选填)</span>
                  <span className="text-[9px] bg-echo-primary/10 text-echo-primary px-1 py-0.5 rounded font-mono">双方均得奖励</span>
                </label>
                <div className="relative">
                  <UserPlus className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    value={referrerPhone}
                    onChange={(e) => setReferrerPhone(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-12 pr-4 text-xs text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="请输入邀请码 (选填)"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">短信验证码</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      type="text"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      required={isOtpSent}
                      disabled={!isOtpSent}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-12 pr-4 text-xs text-white focus:border-echo-primary/50 focus:outline-none transition-all disabled:opacity-50"
                      placeholder={isOtpSent ? "请输入验证码" : "请先获取验证码"}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleSendRegisterOtp}
                    disabled={loading || countdown > 0 || !phone || !password}
                    className="px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold text-echo-primary hover:text-white transition-all disabled:opacity-50 whitespace-nowrap"
                  >
                    {countdown > 0 ? `${countdown}s 后重新获取` : '获取验证码'}
                  </button>
                </div>
              </div>

              {error && <div className="text-red-400 text-xs bg-red-400/10 p-2.5 rounded-xl border border-red-400/20">{error}</div>}

              <button
                type="submit"
                disabled={loading || !isOtpSent}
                className="w-full bg-gradient-to-r from-echo-primary to-echo-secondary text-black font-black py-3 rounded-xl shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:pointer-events-none"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '立即注册'}
              </button>

              <div className="text-[10px] text-gray-500 text-center mt-1 px-2 leading-normal">
                注册即代表您同意 
                <a href="/terms" target="_blank" rel="noopener noreferrer" className="text-echo-primary hover:underline mx-0.5 font-bold">《服务条款》</a> 
                与 
                <a href="/privacy" target="_blank" rel="noopener noreferrer" className="text-echo-primary hover:underline mx-0.5 font-bold">《隐私政策》</a>
              </div>

              <div className="mt-2 text-center">
                <button
                  type="button"
                  onClick={() => { setPhoneMode('login'); setError(null); setIsOtpSent(false); }}
                  className="text-sm text-gray-400 hover:text-echo-primary transition-colors"
                >
                  已有账号？点击登录
                </button>
              </div>
            </form>
          ) : (
            /* 3. 手机号 忘记密码/找回密码表单 */
            <form onSubmit={handlePhoneResetSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase ml-1">手机号码</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="13800138000"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase ml-1">设置新密码 (不低于6位)</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase ml-1">短信验证码</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="text"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      required={isOtpSent}
                      disabled={!isOtpSent}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all disabled:opacity-50"
                      placeholder={isOtpSent ? "请输入验证码" : "请先获取验证码"}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleSendForgotOtp}
                    disabled={loading || countdown > 0 || !phone}
                    className="px-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-echo-primary hover:text-white transition-all disabled:opacity-50 whitespace-nowrap"
                  >
                    {countdown > 0 ? `${countdown}s 后重新获取` : '获取验证码'}
                  </button>
                </div>
              </div>

              {error && <div className="text-red-400 text-xs bg-red-400/10 p-3 rounded-xl border border-red-400/20">{error}</div>}

              <button
                type="submit"
                disabled={loading || !isOtpSent}
                className="w-full bg-gradient-to-r from-echo-primary to-echo-secondary text-black font-black py-4 rounded-2xl shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:pointer-events-none"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '重置密码并登录'}
              </button>

              <div className="mt-4 text-center">
                <button
                  type="button"
                  onClick={() => { setPhoneMode('login'); setError(null); setIsOtpSent(false); }}
                  className="text-sm text-gray-400 hover:text-echo-primary transition-colors"
                >
                  返回登录
                </button>
              </div>
            </form>
          )
        ) : (
          /* 4. 邮箱密码 登录/注册表单 */
          <form onSubmit={handleEmailAuth} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase ml-1">邮箱地址</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                  placeholder="your@email.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase ml-1">访问密码</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {!isLogin && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase ml-1 flex items-center justify-between">
                  <span>邀请码 (选填)</span>
                  <span className="text-[10px] bg-echo-primary/10 text-echo-primary px-1.5 py-0.5 rounded font-mono">双方均得奖励</span>
                </label>
                <div className="relative">
                  <UserPlus className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="text"
                    value={referrerPhone}
                    onChange={(e) => setReferrerPhone(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-white focus:border-echo-primary/50 focus:outline-none transition-all"
                    placeholder="请输入邀请码 (选填)"
                  />
                </div>
              </div>
            )}

            {error && <div className="text-red-400 text-xs bg-red-400/10 p-3 rounded-xl border border-red-400/20">{error}</div>}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-echo-primary to-echo-secondary text-black font-black py-4 rounded-2xl shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isLogin ? '立即登录' : '创建账号')}
            </button>

            {!isLogin && (
              <div className="text-[10px] text-gray-500 text-center mt-2 px-2 leading-normal">
                注册即代表您同意 
                <a href="/terms" target="_blank" rel="noopener noreferrer" className="text-echo-primary hover:underline mx-0.5 font-bold">《服务条款》</a> 
                与 
                <a href="/privacy" target="_blank" rel="noopener noreferrer" className="text-echo-primary hover:underline mx-0.5 font-bold">《隐私政策》</a>
              </div>
            )}

            <div className="mt-4 text-center">
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-sm text-gray-400 hover:text-echo-primary transition-colors"
              >
                {isLogin ? '还没有账号？点击注册' : '已有账号？点击登录'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
