'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/utils/supabase/client';
import { usePlayerStore } from '@/store/playerStore';
import { useLanguageStore } from '@/store/languageStore';
import { Play, TrendingUp, Sparkles, Globe, Pause, Music2 } from 'lucide-react';

const SongRow = ({ song, index, currentTrack, isPlaying, onPlay }: any) => {
  const isActive = currentTrack?.id === song.id;
  return (
    <div
      className={`flex items-center gap-3 px-3 py-2.5 rounded-2xl transition-all cursor-pointer group ${
        isActive ? 'bg-echo-primary/10 border border-echo-primary/20' : 'hover:bg-white/5 border border-transparent'
      }`}
      onClick={onPlay}
    >
      {index !== undefined && (
        <div className={`w-5 text-xs font-black italic shrink-0 text-center ${isActive ? 'text-echo-primary' : 'text-gray-700 group-hover:text-gray-400'}`}>
          {isActive && isPlaying ? (
            <div className="flex gap-[2px] items-end h-3 justify-center">
              <div className="w-[3px] bg-echo-primary animate-[music-bar_0.6s_ease-in-out_infinite]" />
              <div className="w-[3px] bg-echo-primary animate-[music-bar_0.9s_ease-in-out_infinite]" />
              <div className="w-[3px] bg-echo-primary animate-[music-bar_0.7s_ease-in-out_infinite]" />
            </div>
          ) : (
            String(index + 1).padStart(2, '0')
          )}
        </div>
      )}

      <div className="relative w-10 h-10 rounded-xl overflow-hidden shrink-0 shadow-md">
        <img src={song.cover_url || song.cover} alt={song.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          {isActive && isPlaying
            ? <Pause className="w-4 h-4 fill-white text-white" />
            : <Play className="w-4 h-4 fill-white text-white ml-0.5" />
          }
        </div>
      </div>

      <div className="flex-1 min-w-0">
        <h4 className={`font-bold text-sm truncate ${isActive ? 'text-echo-primary' : 'text-white'}`}>
          {song.title}
        </h4>
        <div className="flex items-center gap-2 mt-0.5">
          {song.creator_id ? (
            <Link 
              href={`/artist/${song.creator_id}`} 
              onClick={(e) => e.stopPropagation()}
              className="text-gray-500 text-[11px] truncate hover:text-echo-primary hover:underline transition-colors inline-block"
            >
              {song.creator?.display_name || song.creator_name || song.artist}
            </Link>
          ) : (
            <p className="text-gray-500 text-[11px] truncate">
              {song.creator?.display_name || song.creator_name || song.artist}
            </p>
          )}
          <span className="text-gray-700 text-[9px]">•</span>
          <span className="text-gray-500 text-[9px] flex items-center font-mono">
            {song.play_count ?? 0} 次收听
          </span>
        </div>
      </div>

      <div className="shrink-0 flex items-center gap-1 px-2 py-0.5 rounded-lg bg-echo-secondary/10 border border-echo-secondary/20 text-[9px] font-black text-echo-secondary uppercase">
        <Sparkles size={8} />
        Earn
      </div>
    </div>
  );
};

export default function HomeClientPage() {
  const { setTrack, setPlaylist, currentTrack, isPlaying, togglePlay } = usePlayerStore();
  const { t } = useLanguageStore();
  const [hotPlays, setHotPlays] = useState<any[]>([]);
  const [trendingDiscoveries, setTrendingDiscoveries] = useState<any[]>([]);
  const [newReleases, setNewReleases] = useState<any[]>([]);
  const [creators, setCreators] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [winners, setWinners] = useState<any[]>([]);
  const [totalEcholoop, setTotalEcholoop] = useState<number>(0);
  const [activeCreatorsCount, setActiveCreatorsCount] = useState<number>(0);
  const supabase = createClient();

  useEffect(() => {
    const fetchWinners = async () => {
      try {
        const { data } = await supabase
          .from('arena_registrations')
          .select('*, song:songs(*, creator:profiles(display_name, avatar_url))')
          .eq('status', 'winner')
          .order('arena_date', { ascending: false })
          .order('votes_count', { ascending: false })
          .limit(10);

        if (data && data.length > 0) {
          const winnerSongs = data
            .filter((reg: any) => reg.song !== null)
            .map((reg: any) => ({
              ...reg.song,
              votes: reg.votes_count
            }));
          setWinners(winnerSongs);
        } else {
          setWinners([]);
        }
      } catch (err) {
        console.error('Failed to fetch arena winners:', err);
        setWinners([]);
      }
    };
    fetchWinners();
  }, [supabase]);

  useEffect(() => {
    const fetchSongs = async () => {
      try {
        setLoading(true);

        const { data: hotData } = await supabase
          .from('daily_top_songs_with_details')
          .select('*')
          .order('today_plays', { ascending: false })
          .limit(10);
        
        if (hotData && hotData.length > 0) {
          const mappedHot = hotData.map(song => ({
            ...song,
            play_count: song.today_plays || 0
          }));
          setHotPlays(mappedHot);
        } else {
          setHotPlays([]);
        }

        const { data: trendData } = await supabase
          .from('trending_discoveries_score')
          .select('*')
          .limit(10);

        if (trendData && trendData.length > 0) {
          const mappedTrend = trendData.map(song => ({
            id: song.id,
            title: song.title,
            artist: song.artist || '极声创作者',
            cover_url: song.cover_url || song.cover,
            audio_url: song.audio_url,
            earn_rate: song.earn_rate,
            tags: song.tags,
            lyrics: song.lyrics,
            creator_id: song.creator_id,
            creator: {
              display_name: song.creator_name,
              avatar_url: song.creator_avatar
            },
            creator_name: song.creator_name || '未知创作者',
            creator_avatar: song.creator_avatar,
            play_count: song.play_count || 0,
            created_at: song.created_at,
          }));
          setTrendingDiscoveries(mappedTrend);
        } else {
          setTrendingDiscoveries([]);
        }

        const { data: freshData } = await supabase
          .from('songs')
          .select('*, creator:profiles(display_name, avatar_url)')
          .order('created_at', { ascending: false })
          .limit(10);

        if (freshData && freshData.length > 0) {
          const mappedFresh = freshData.map(song => ({
            id: song.id,
            title: song.title,
            artist: song.artist || '极声创作者',
            cover_url: song.cover_url || song.cover,
            audio_url: song.audio_url,
            earn_rate: song.earn_rate,
            tags: song.tags,
            lyrics: song.lyrics,
            creator_id: song.creator_id,
            creator: song.creator,
            creator_name: song.creator?.display_name || '未知创作者',
            creator_avatar: song.creator?.avatar_url,
            play_count: song.likes || 0,
            created_at: song.created_at,
          }));
          setNewReleases(mappedFresh);
        } else {
          setNewReleases([]);
        }

      } catch (err) {
        console.error('Error fetching homepage lists:', err);
      } finally {
        setLoading(false);
      }
    };

    const fetchCreators = async () => {
      const { data } = await supabase
        .from('emerging_artists_score')
        .select('*')
        .limit(10);
      
      if (data && data.length > 0) {
        const mappedCreators = data.map((c: any) => ({
          id: c.creator_id,
          name: c.creator_name,
          avatar: c.creator_avatar,
          tag: `热度: ${c.artist_score}分 | 近期粉丝: +${c.total_follows}`,
          score: c.artist_score
        }));
        setCreators(mappedCreators);
      }
    };

    const fetchGlobalStats = async () => {
      try {
        const { data: txs } = await supabase
          .from('transactions')
          .select('amount')
          .eq('type', 'listen_reward');
        const sum = txs?.reduce((acc, curr) => acc + Number(curr.amount), 0) || 0;
        setTotalEcholoop(sum);

        const { count } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true });
        setActiveCreatorsCount(count || 0);
      } catch (e) {
        console.error('Error fetching global stats:', e);
      }
    };

    fetchSongs();
    fetchCreators();
    fetchGlobalStats();

    const handleRefresh = () => {
      fetchSongs();
      fetchGlobalStats();
    };

    window.addEventListener('play-count-updated', handleRefresh);
    return () => {
      window.removeEventListener('play-count-updated', handleRefresh);
    };
  }, [supabase]);
 
  // 自动播放分享歌曲逻辑（主要面向跳过了开屏动画的已登录老用户）
  useEffect(() => {
    const playSharedSong = async () => {
      if (typeof window !== 'undefined') {
        const params = new URLSearchParams(window.location.search);
        const songId = params.get('songId');
        
        if (songId) {
          // Clear only the songId parameter from URL immediately to prevent infinite loop / override on subsequent song clicks
          params.delete('songId');
          const newSearch = params.toString();
          const newUrl = window.location.pathname + (newSearch ? `?${newSearch}` : '');
          window.history.replaceState({}, '', newUrl);

          if (String(currentTrack?.id) !== String(songId)) {
            try {
              const { data: song } = await supabase
                .from('songs')
                .select('*')
                .eq('id', songId)
                .single();
                
              if (song) {
                const track = {
                  id: song.id,
                  title: song.title,
                  artist: song.artist,
                  cover: song.cover_url || song.cover,
                  src: song.audio_url || 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
                  earnRate: Number(song.earn_rate) || 0.005,
                  lyrics: song.lyrics,
                };
                setPlaylist([track]);
                setTrack(track);
              }
            } catch (err) {
              console.error('Failed to load and play shared song on HomeClientPage:', err);
            }
          }
        }
      }
    };
    
    const timer = setTimeout(() => {
      playSharedSong();
    }, 500);
    return () => clearTimeout(timer);
  }, [supabase, currentTrack, setTrack, setPlaylist]);

  // 本日热播：优先从 daily_top_songs_with_details 视图，若为空则降级使用 trending 数据
  const hotPlaysDisplay = hotPlays.length > 0 ? hotPlays : trendingDiscoveries;
  const freshSongs = newReleases;

  const handlePlay = (song: any) => {
    if (currentTrack?.id === song.id) {
      togglePlay();
    } else {
      setTrack({
        id: song.id,
        title: song.title,
        artist: song.artist,
        cover: song.cover_url || song.cover,
        src: song.audio_url || 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
        earnRate: Number(song.earn_rate) || 0.005,
        lyrics: song.lyrics,
      });
    }
  };

  return (
    <div className="space-y-10 pb-20">
      <section className="relative rounded-[2rem] bg-gradient-to-r from-amber-950/15 via-black to-purple-950/15 border border-amber-500/20 p-5 md:p-8 overflow-hidden shadow-[0_0_40px_rgba(245,158,11,0.06)]">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 blur-[100px] rounded-full pointer-events-none" />
        <div className="relative z-10 space-y-5">
          <div className="flex items-center">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/25 text-[9px] font-black text-amber-400 uppercase tracking-widest animate-pulse">
                <Sparkles className="w-3 h-3" />
                🏆 DAO 听审认证
              </div>
              <h2 className="text-xl md:text-2xl font-black text-white leading-none uppercase tracking-tighter italic">
                本日推荐金曲 TOP10
              </h2>
            </div>
          </div>

          {winners.length > 0 ? (
            <div className="flex gap-2.5 overflow-x-auto pb-2 -mx-1 px-1">
              {winners.map((song, index) => (
                <div
                  key={song.id}
                  className="w-24 shrink-0 bg-white/5 border border-white/10 hover:border-amber-500/40 rounded-xl p-2 transition-all group cursor-pointer"
                  onClick={() => handlePlay(song)}
                >
                  <div className="relative w-full aspect-square rounded-lg overflow-hidden mb-2 shadow-md">
                    <img src={song.cover_url || song.cover} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <div className="absolute top-1 left-1 px-1.5 py-0.5 bg-amber-400 text-black text-[7px] font-black rounded">
                      #{index + 1}
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                      <Play className="w-5 h-5 fill-white text-white ml-0.5" />
                    </div>
                  </div>
                  <p className="text-white text-[10px] font-bold truncate leading-tight">{song.title}</p>
                  <p className="text-amber-400 text-[9px] font-mono truncate">{song.artist}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center flex flex-col items-center justify-center space-y-2 border border-dashed border-amber-500/20 rounded-2xl bg-amber-500/5">
              <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
              <h3 className="text-sm font-bold text-white italic">等你加入</h3>
              <p className="text-[10px] text-gray-500">今日听审擂台暂无胜出金曲，快去发现页投票，或者上传你的歌曲吧！</p>
            </div>
          )}
        </div>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-panel p-5 rounded-[2rem] border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-base font-black text-white uppercase italic flex items-center gap-2">
              <div className="w-1.5 h-5 bg-echo-primary rounded-full" />
              本日热播 TOP10
            </h2>
            <span className="text-[9px] text-gray-600 font-mono uppercase">Real-time</span>
          </div>
          <div className="space-y-1">
            {loading ? (
              [1,2,3].map(i => <div key={i} className="h-14 bg-white/5 rounded-2xl animate-pulse" />)
            ) : hotPlays.length > 0 ? (
              hotPlays.slice(0, 10).map((song, index) => (
                <SongRow key={song.id} song={song} index={index} currentTrack={currentTrack} isPlaying={isPlaying} onPlay={() => handlePlay(song)} />
              ))
            ) : (
              <div className="py-12 text-center flex flex-col items-center justify-center space-y-3">
                <Music2 className="w-8 h-8 text-echo-primary/40 animate-pulse" />
                <h3 className="text-xs font-bold text-white italic">等你加入</h3>
                <p className="text-[10px] text-gray-500">当前还没有热播歌曲，上传您的音乐开启播放收益吧！</p>
              </div>
            )}
          </div>
        </div>

        <div className="glass-panel p-5 rounded-[2rem] border border-white/10 relative overflow-hidden">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-base font-black text-white uppercase italic flex items-center gap-2">
              <div className="w-1.5 h-5 bg-echo-secondary rounded-full" />
              新锐艺人 TOP10
            </h2>
            <span className="text-[9px] text-gray-600 font-mono uppercase">Rising Stars</span>
          </div>
          <div className="flex flex-col gap-3">
            {creators.length > 0 ? creators.map((creator) => (
              <Link href={`/artist/${creator.id}`} key={creator.id} className="flex items-center gap-3 p-2 rounded-2xl hover:bg-white/5 transition-colors group">
                <div className="w-10 h-10 rounded-xl bg-gray-800 border border-white/10 overflow-hidden shrink-0">
                  <img src={creator.avatar || `https://api.dicebear.com/7.x/adventurer/svg?seed=${creator.id}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-bold text-sm truncate group-hover:text-echo-primary transition-colors">{creator.name || '极声创作者'}</h4>
                  <p className="text-echo-secondary text-[10px] font-mono">{creator.tag}</p>
                </div>
                <div className="px-3 py-1 rounded-full bg-echo-secondary/10 border border-echo-secondary/30 text-echo-secondary text-[10px] font-bold uppercase shrink-0 group-hover:bg-echo-secondary group-hover:text-black transition-colors">
                  去主页关注
                </div>
              </Link>
            )) : (
              [
                { name: 'CyberNomad', tag: '电子 / Synthwave', seed: 'cybernomad' },
                { name: 'Guqin Wanderer', tag: '国风 / Ambient', seed: 'guqin' },
                { name: 'LoFi Coffee', tag: '爵士 / LoFi', seed: 'lofi' },
              ].map((c) => (
                <div key={c.seed} className="flex items-center gap-3 p-2 rounded-2xl hover:bg-white/5 transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-gray-800 border border-white/10 overflow-hidden shrink-0">
                    <img src={`https://api.dicebear.com/7.x/lorelei/svg?seed=${c.seed}`} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-bold text-sm truncate">{c.name}</h4>
                    <p className="text-echo-secondary text-[10px] font-mono">{c.tag}</p>
                  </div>
                  <div className="px-3 py-1 rounded-full bg-echo-secondary/10 border border-echo-secondary/30 text-echo-secondary text-[10px] font-bold uppercase shrink-0">
                    关注
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-black text-white uppercase tracking-tighter flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-echo-primary" />
            热门发现
          </h2>
          <Link href="/discover" className="text-[10px] font-bold text-gray-500 uppercase hover:text-echo-primary transition-colors">
            查看全部 →
          </Link>
        </div>
        <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-2 space-y-0.5">
          {hotPlaysDisplay.length > 0 ? (
            hotPlaysDisplay.map((song, i) => (
              <SongRow key={song.id} song={song} index={i} currentTrack={currentTrack} isPlaying={isPlaying} onPlay={() => handlePlay(song)} />
            ))
          ) : (
            <div className="py-10 text-center flex flex-col items-center justify-center space-y-2">
              <TrendingUp className="w-6 h-6 text-echo-primary/30 animate-pulse" />
              <h3 className="text-xs font-bold text-white italic">等你加入</h3>
              <p className="text-[9px] text-gray-500">当前没有被发现的歌曲，快去上传第一首吧！</p>
            </div>
          )}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-black text-white uppercase tracking-tighter flex items-center gap-2">
            <Globe className="w-5 h-5 text-echo-secondary" />
            新歌速递
          </h2>
        </div>
        <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-2 space-y-0.5">
          {freshSongs.length > 0 ? (
            freshSongs.map((song, i) => (
              <SongRow key={song.id} song={song} index={i} currentTrack={currentTrack} isPlaying={isPlaying} onPlay={() => handlePlay(song)} />
            ))
          ) : (
            <div className="py-10 text-center flex flex-col items-center justify-center space-y-2">
              <Globe className="w-6 h-6 text-echo-secondary/30 animate-pulse" />
              <h3 className="text-xs font-bold text-white italic">等你加入</h3>
              <p className="text-[9px] text-gray-500">当前暂无新发布歌曲，上传并分享您的第一首原创音乐！</p>
            </div>
          )}
        </div>
      </section>

      <section className="grid grid-cols-3 gap-3">
        <div className="glass-panel p-4 rounded-2xl border border-white/5 bg-gradient-to-br from-echo-primary/5 to-transparent text-center">
          <p className="text-[9px] text-gray-600 font-bold uppercase mb-1">全网累计收听奖励</p>
          <div className="text-lg font-black text-white tracking-tighter">
            {totalEcholoop > 0 ? totalEcholoop.toFixed(2) : '0.00'}{' '}
            <span className="text-[10px] text-echo-primary">ECHO</span>
          </div>
          <p className="text-[8px] text-emerald-400 font-bold mt-0.5">● 智能合约实时结算</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl border border-white/5 text-center">
          <p className="text-[9px] text-gray-600 font-bold uppercase mb-1">活跃创作者节点</p>
          <div className="text-lg font-black text-white tracking-tighter">
            {activeCreatorsCount > 0 ? activeCreatorsCount : '0'}{' '}
            <span className="text-[10px] text-echo-secondary">Nodes</span>
          </div>
          <p className="text-[8px] text-indigo-400 font-bold mt-0.5">● 去中心化节点认证</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl border border-white/5 text-center">
          <p className="text-[9px] text-gray-600 font-bold uppercase mb-1">社区分润率</p>
          <div className="text-lg font-black text-white tracking-tighter">
            100.0% <span className="text-[10px] text-green-500">Live</span>
          </div>
          <p className="text-[8px] text-green-400 font-bold mt-0.5">● 100% 利润社区回馈</p>
        </div>
      </section>
    </div>
  );
}
